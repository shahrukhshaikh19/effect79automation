AI Se Best Output Nikalwane Ke Liye 3 Pro Tips (Jab Aap Prompt Dein)

AI ko Ek Saath Sab Kuch Mat Banane Bolein: Agar aap bolenge "Poori brand website bana do", toh AI shortcut lekar cheap UI banayega. Iske bajaye `UI_design_skill.md` follow karte hue section-by-section banwayein. Har step mein Anti-Cheap UI Rules, `backdrop-blur-md` cap, aur custom easing `[0.16, 1, 0.3, 1]` lock rakhein.

Step 1: "Using UI_design_skill.md, build ONLY the Hero (first viewport) and the Floating Studio Navigation. One WebGL/shader placeholder canvas, one oversized editorial headline with a masked stagger reveal, and the liquid-glass pill header. Do not build the gallery or modal yet."

Step 2: "Using UI_design_skill.md, build ONLY the Staggered 3D Project Showcase Gallery. Asymmetrical editorial grid, 16:10 or 4:5 glass bezel frames, monospace index numbers (01 / 06), and cursor-tracking glare that writes --x and --y in requestAnimationFrame — never React useState. Cap blur at backdrop-blur-md."

Step 3: "Using UI_design_skill.md, build ONLY the Spatial Case Study Modal. Full-viewport glass drawer, spring physics (stiffness 320, damping 32), live launch pill, tech architecture line, and Lenis momentum scroll inside the modal. Do not restyle the hero or gallery."

Real Media / Canvas Placeholder Dein: Cheap UI aksar isliye dikhta hai kyunki AI dummy boxes mein random colors bhar deta hai. Apne 3D projects ke high-res WebM/MP4 loops ya live R3F scene ko un glass frames ke andar embed karein—Liquid Glass ka asli jaadu tabhi dikhta hai jab uske peeche aapke 3D shaders ke colors refract hote hain.

Typography Load Karna Na Bhulein: AI default Inter ya Arial laga deta hai. `layout.tsx` / `index.html` mein display font `Syne` (ya `Clash Display`; commercial option `PP Neue Montreal`) aur mono font `Geist Mono` (fallback `JetBrains Mono`) load karein. Space Grotesk mat use karein—sirf yeh pair UI ko Awwwards-level editorial scale deta hai.
