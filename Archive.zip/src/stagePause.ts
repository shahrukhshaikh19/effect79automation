import { useEffect, useState } from "react"

let paused = false
let locks = 0
let scrollY = 0
const listeners = new Set<() => void>()

function emit() {
  document.documentElement.dataset.stagePaused = paused ? "true" : "false"
  listeners.forEach((listener) => listener())
}

export function isStagePaused() {
  return paused
}

export function setStagePaused(next: boolean) {
  if (paused === next) return
  paused = next
  emit()
}

export function subscribeStagePaused(listener: () => void) {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

export function useStagePaused() {
  const [value, setValue] = useState(paused)
  useEffect(() => subscribeStagePaused(() => setValue(paused)), [])
  return value
}

function lockPage(y = window.scrollY) {
  scrollY = y
  const body = document.body
  const gap = window.innerWidth - document.documentElement.clientWidth
  body.style.position = "fixed"
  body.style.top = `-${scrollY}px`
  body.style.left = "0"
  body.style.right = "0"
  body.style.width = "100%"
  body.style.paddingRight = `${gap}px`
  setStagePaused(true)
}

function unlockPage() {
  const body = document.body
  body.style.position = ""
  body.style.top = ""
  body.style.left = ""
  body.style.right = ""
  body.style.width = ""
  body.style.paddingRight = ""
  window.scrollTo(0, scrollY)
  setStagePaused(false)
}

export function useStageLock(y: number) {
  useEffect(() => {
    locks += 1
    if (locks === 1) lockPage(y)
    return () => {
      locks -= 1
      if (locks === 0) unlockPage()
    }
  }, [y])
}
