import { Gallery } from "./components/Gallery"
import { Hero } from "./components/Hero"
import { StudioNav } from "./components/StudioNav"

export default function App() {
  return (
    <>
      <StudioNav />
      <main>
        <Hero />
        <Gallery />
      </main>
    </>
  )
}
