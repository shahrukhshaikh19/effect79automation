import { StrictMode } from "react"
import { createRoot } from "react-dom/client"
import "@fontsource/syne/600.css"
import "@fontsource/syne/700.css"
import "@fontsource/syne/800.css"
import "@fontsource/geist-mono/400.css"
import "@fontsource/geist-mono/500.css"
import "./index.css"
import App from "./App"

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
