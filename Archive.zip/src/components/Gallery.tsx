import { useState } from "react"
import { CaseStudyModal } from "./CaseStudyModal"
import { ProjectCard, type Project } from "./ProjectCard"

const PROJECTS: readonly Project[] = [
  { title: "Halo", year: "2026", tags: ["R3F", "Custom GLSL"], variant: 0 },
  { title: "Caustic", year: "2025", tags: ["GLSL", "Caustics"], variant: 1 },
  { title: "Lathe", year: "2026", tags: ["R3F", "Lathe"], variant: 2 },
  { title: "Index", year: "2025", tags: ["WebGL", "Index"], variant: 3 },
  { title: "Field", year: "2024", tags: ["GLSL", "Field"], variant: 4 },
  { title: "Meridian", year: "2026", tags: ["R3F", "Arc"], variant: 5 },
]

export function Gallery() {
  const [open, setOpen] = useState<{
    project: Project
    index: number
    scrollY: number
  } | null>(null)

  return (
    <section
      id="work"
      aria-label="Selected work"
      className="bg-[#030305] px-5 pt-4 pb-28 sm:px-10 md:pb-36 lg:px-16"
    >
      <h2 className="sr-only">Selected work</h2>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        {PROJECTS.map((project, index) => (
          <ProjectCard
            key={project.title}
            project={project}
            index={index}
            total={PROJECTS.length}
            onOpen={(scrollY) => setOpen({ project, index, scrollY })}
          />
        ))}
      </div>
      <CaseStudyModal
        project={open?.project ?? null}
        index={open?.index ?? 0}
        total={PROJECTS.length}
        scrollY={open?.scrollY ?? 0}
        onClose={() => setOpen(null)}
      />
    </section>
  )
}
