import { motion, useReducedMotion } from "framer-motion"
import { useEffect, useRef, useState } from "react"
import { EASE } from "../ease"
import { ProjectPreview } from "./ProjectPreview"

export type Project = {
  title: string
  year: string
  tags: readonly string[]
  variant: number
}

export function ProjectCard({
  project,
  index,
  total,
  onOpen,
}: {
  project: Project
  index: number
  total: number
  onOpen: (scrollY: number) => void
}) {
  const reduce = useReducedMotion()
  const frameRef = useRef<HTMLDivElement>(null)
  const pillRef = useRef<HTMLButtonElement>(null)
  const titleRef = useRef<HTMLHeadingElement>(null)
  const [titleShown, setTitleShown] = useState(false)
  const label = `${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`

  useEffect(() => {
    const title = titleRef.current
    if (!title || reduce) return
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (!entry?.isIntersecting) return
        setTitleShown(true)
        observer.disconnect()
      },
      { threshold: 0.6 },
    )
    observer.observe(title)
    return () => observer.disconnect()
  }, [reduce])

  useEffect(() => {
    const frame = frameRef.current
    const pill = pillRef.current
    if (!frame || !pill) return

    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches
    let frameId = 0
    let inside = false
    let pointerX = 50
    let pointerY = 18
    let targetX = 0
    let targetY = 0
    let currentX = 0
    let currentY = 0
    let placed = false

    const tick = () => {
      frameId = 0
      const blend = reduceMotion ? 1 : 0.22
      currentX += (targetX - currentX) * blend
      currentY += (targetY - currentY) * blend
      frame.style.setProperty("--x", `${pointerX}%`)
      frame.style.setProperty("--y", `${pointerY}%`)
      pill.style.transform = `translate3d(${currentX}px, ${currentY}px, 0) translate(-50%, -50%)`
      const traveling =
        Math.abs(targetX - currentX) > 0.4 || Math.abs(targetY - currentY) > 0.4
      if (inside && traveling) frameId = window.requestAnimationFrame(tick)
    }

    const queue = () => {
      if (!frameId) frameId = window.requestAnimationFrame(tick)
    }

    const place = (event: PointerEvent) => {
      const rect = frame.getBoundingClientRect()
      if (rect.width === 0 || rect.height === 0) return
      pointerX = ((event.clientX - rect.left) / rect.width) * 100
      pointerY = ((event.clientY - rect.top) / rect.height) * 100
      const padX = Math.min(78, rect.width * 0.22)
      const padY = Math.min(28, rect.height * 0.16)
      targetX = Math.min(rect.width - padX, Math.max(padX, event.clientX - rect.left))
      targetY = Math.min(rect.height - padY, Math.max(padY, event.clientY - rect.top))
      if (!placed) {
        currentX = targetX
        currentY = targetY
        placed = true
      }
      inside = true
      queue()
    }

    const leave = () => {
      inside = false
      pointerX = 50
      pointerY = 18
      queue()
    }

    frame.addEventListener("pointermove", place)
    frame.addEventListener("pointerleave", leave)

    return () => {
      window.cancelAnimationFrame(frameId)
      frame.removeEventListener("pointermove", place)
      frame.removeEventListener("pointerleave", leave)
    }
  }, [])

  return (
    <article
      className="group min-w-0 cursor-pointer"
      aria-label={`${project.title}, ${label}`}
      tabIndex={0}
      onMouseDown={(event) => event.preventDefault()}
      onClick={() => onOpen(window.scrollY)}
      onKeyDown={(event) => {
        if (event.key !== "Enter" && event.key !== " ") return
        event.preventDefault()
        onOpen(window.scrollY)
      }}
    >
      <div className="w-full rounded-[28px] border border-white/10 bg-white/[0.03] p-2.5 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.35)]">
        <div
          ref={frameRef}
          className="project-frame aspect-landscape relative w-full overflow-hidden rounded-[18px]"
        >
          <div className="project-media absolute inset-0 origin-center transition-transform duration-700 ease-studio group-hover:scale-[1.03]">
            <ProjectPreview variant={project.variant} />
          </div>
          <p className="pointer-events-none absolute inset-x-4 bottom-4 z-10 font-mono text-[11px] uppercase tracking-[0.2em] text-white/75 opacity-0 transition-opacity duration-700 ease-studio group-hover:opacity-100">
            {project.tags.join("  ·  ")}
          </p>
          <button
            ref={pillRef}
            type="button"
            className="pointer-events-none absolute top-0 left-0 z-20 rounded-full border border-white/[0.12] bg-white/[0.04] px-3.5 py-2 font-mono text-[11px] uppercase tracking-[0.2em] text-white opacity-0 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.35)] backdrop-blur-md backdrop-saturate-150 transform-gpu [contain:layout_paint] transition-opacity duration-500 ease-studio group-hover:pointer-events-auto group-hover:opacity-100"
            onMouseDown={(event) => event.preventDefault()}
            onClick={(event) => {
              event.stopPropagation()
              onOpen(window.scrollY)
            }}
          >
            View case ↗
          </button>
        </div>
      </div>
      <div className="mt-5 sm:mt-6">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-white/45">
          {label}
        </p>
        <div className="mt-3 flex items-baseline justify-between gap-4">
          <h3
            ref={titleRef}
            className="min-w-0 overflow-hidden font-display text-[clamp(1.75rem,2.4vw,2.5rem)] font-semibold uppercase leading-[1.05] tracking-[-0.04em] text-white"
          >
            <motion.span
              className="block"
              initial={{ y: reduce ? "0%" : "100%" }}
              animate={{ y: titleShown || reduce ? "0%" : "100%" }}
              transition={
                reduce ? { duration: 0 } : { duration: 1.05, ease: EASE }
              }
            >
              {project.title}
            </motion.span>
          </h3>
          <p className="shrink-0 font-mono text-[11px] uppercase tracking-[0.2em] text-white/40">
            {project.year}
          </p>
        </div>
      </div>
    </article>
  )
}
