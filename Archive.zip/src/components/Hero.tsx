import { motion, useReducedMotion } from "framer-motion"
import { useEffect, useState } from "react"
import { EASE } from "../ease"
import { ShaderStage } from "./ShaderStage"

const LINES = ["Light", "Field"] as const

export function Hero() {
  const reduce = useReducedMotion()
  const [fontsReady, setFontsReady] = useState(false)

  useEffect(() => {
    let cancelled = false
    const timeout = window.setTimeout(() => {
      if (!cancelled) setFontsReady(true)
    }, 900)

    document.fonts.ready.then(() => {
      if (!cancelled) setFontsReady(true)
    })

    return () => {
      cancelled = true
      window.clearTimeout(timeout)
    }
  }, [])

  return (
    <section className="relative w-full bg-[#030305]" aria-label="Hero">
      <ShaderStage />
      <div className="relative z-10 px-5 pt-24 pb-4 sm:px-10 sm:pt-28 lg:px-16 lg:pb-6">
        <h1 className="font-display text-[clamp(2.75rem,5vw,4.5rem)] font-extrabold uppercase leading-[0.95] tracking-[-0.04em] text-white">
          {LINES.map((line, index) => (
            <span key={line} className="block overflow-hidden">
              <motion.span
                className="block"
                initial={{ y: "100%" }}
                animate={{ y: fontsReady ? "0%" : "100%" }}
                transition={
                  reduce || !fontsReady
                    ? { duration: 0 }
                    : {
                        duration: 1.15,
                        delay: 0.12 + index * 0.1,
                        ease: EASE,
                      }
                }
              >
                {line}
              </motion.span>
            </span>
          ))}
        </h1>
      </div>
    </section>
  )
}
