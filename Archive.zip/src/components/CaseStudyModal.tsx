import { motion, useReducedMotion } from "framer-motion"
import Lenis from "lenis"
import { useEffect, useId, useState, useRef } from "react"
import { EASE } from "../ease"
import { useStageLock } from "../stagePause"
import { ProjectPreview } from "./ProjectPreview"
import type { Project } from "./ProjectCard"

const SPRING = { type: "spring" as const, stiffness: 320, damping: 32, mass: 1 }

const STUDIES: Record<string, { architecture: string; notes: readonly string[] }> = {
  Halo: {
    architecture: "R3F • Custom GLSL • Postprocessing",
    notes: [
      "A single specular sheet drifts through an obsidian field. The study keeps one draw call and lets the glass read as light, not as a colored panel.",
      "Grain stays in the shader. The bezel only frames the pass, so the highlight can move without a second blur layer over the canvas.",
    ],
  },
  Caustic: {
    architecture: "GLSL • Caustics • Refraction",
    notes: [
      "Concentric rings stand in for a caustic pool. The radius is cheap, the falloff is tight, and the frame stays dark enough for the type to hold.",
      "No post stack. The ring is the material, and the drawer above it is the only glass surface on screen.",
    ],
  },
  Lathe: {
    architecture: "R3F • Lathe • Displacement",
    notes: [
      "Vertical ribs turn a flat quad into a lathed profile. The motion is a sine in the fragment shader, paused with the rest of the stage when this drawer closes.",
      "The study is about the profile, not a scene graph. One mesh, one material, a portrait frame.",
    ],
  },
  Index: {
    architecture: "WebGL • Index Field • Postprocessing",
    notes: [
      "Diagonal bands index the frame like a contact sheet. Each stripe is a fold in the same field, not a stack of cards.",
      "The architecture line is the whole technical caption: the pass, the pattern, and a light post treatment that never leaves this study.",
    ],
  },
  Field: {
    architecture: "GLSL • Field • Grid",
    notes: [
      "A measured grid sits in the void. The lines are a threshold on a repeated cell, so the preview stays a field instead of a diagram.",
      "Year and index stay in mono. The grid is the picture.",
    ],
  },
  Meridian: {
    architecture: "R3F • Arc • Postprocessing",
    notes: [
      "An arc and a horizon share one fragment. The meridian is the only bright edge, held against the same obsidian as the hero.",
      "Closing the drawer returns the scroll to the gallery and lets the paused canvases render again.",
    ],
  },
}

export function CaseStudyModal({
  project,
  index,
  total,
  scrollY,
  onClose,
}: {
  project: Project | null
  index: number
  total: number
  scrollY: number
  onClose: () => void
}) {
  if (!project) return null
  return (
    <CaseStudy
      project={project}
      index={index}
      total={total}
      scrollY={scrollY}
      onClose={onClose}
    />
  )
}

function CaseStudy({
  project,
  index,
  total,
  scrollY,
  onClose,
}: {
  project: Project
  index: number
  total: number
  scrollY: number
  onClose: () => void
}) {
  const reduce = useReducedMotion()
  const titleId = useId()
  const drawerRef = useRef<HTMLDivElement>(null)
  const [present, setPresent] = useState(true)
  const study = STUDIES[project.title]
  const label = `${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}`
  const spring = reduce ? { duration: 0 } : SPRING

  const requestClose = () => setPresent(false)

  useEffect(() => {
    const drawer = drawerRef.current
    drawer?.focus({ preventScroll: true })
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") requestClose()
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [])

  return (
    <>
      <motion.button
        type="button"
        aria-label="Close case study"
        className="fixed inset-0 z-[70] bg-black/60"
        initial={{ opacity: 0 }}
        animate={{ opacity: present ? 1 : 0 }}
        transition={{ duration: reduce ? 0 : 0.45, ease: EASE }}
        onClick={requestClose}
      />
      <div className="pointer-events-none fixed inset-0 z-[71] flex items-center justify-center p-6 sm:p-10">
      <motion.div
        ref={drawerRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        tabIndex={-1}
        className="pointer-events-auto flex max-h-[78vh] w-full max-w-4xl flex-col overflow-hidden rounded-[32px] border border-white/[0.12] bg-white/[0.04] shadow-[inset_0_1px_0_0_rgba(255,255,255,0.35)] backdrop-blur-md backdrop-saturate-150 transform-gpu [contain:layout_paint] outline-none"
        initial={{ y: 28, opacity: 0 }}
        animate={{ y: present ? 0 : 28, opacity: present ? 1 : 0 }}
        transition={spring}
        onAnimationComplete={() => {
          if (!present) onClose()
        }}
      >
        <CaseStudyBody
          project={project}
          label={label}
          titleId={titleId}
          architecture={study?.architecture ?? project.tags.join(" • ")}
          notes={study?.notes ?? []}
          scrollY={scrollY}
          onClose={requestClose}
        />
      </motion.div>
      </div>
    </>
  )
}

function CaseStudyBody({
  project,
  label,
  titleId,
  architecture,
  notes,
  scrollY,
  onClose,
}: {
  project: Project
  label: string
  titleId: string
  architecture: string
  notes: readonly string[]
  scrollY: number
  onClose: () => void
}) {
  const reduce = useReducedMotion()
  const wrapperRef = useRef<HTMLDivElement>(null)
  const contentRef = useRef<HTMLDivElement>(null)
  useStageLock(scrollY)

  useEffect(() => {
    const wrapper = wrapperRef.current
    const content = contentRef.current
    if (!wrapper || !content) return

    const lenis = new Lenis({
      wrapper,
      content,
      eventsTarget: wrapper,
      autoRaf: true,
      smoothWheel: true,
      overscroll: false,
      lerp: 0.1,
    })

    return () => lenis.destroy()
  }, [])

  return (
    <>
      <header className="shrink-0 px-6 pt-5 pb-3 sm:px-8">
        <div className="flex items-center justify-between gap-4">
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-white/50">
            {label}
            <span className="px-3 text-white/30">·</span>
            {project.year}
          </p>
          <div className="flex items-center gap-3 sm:gap-4">
            <button
              type="button"
              className="rounded-full bg-white px-6 py-2.5 font-display text-sm font-medium text-black transition-transform duration-500 ease-studio hover:scale-105"
            >
              Live Launch
            </button>
            <button
              type="button"
              onClick={onClose}
              className="font-mono text-[11px] uppercase tracking-[0.2em] text-white/70 transition-colors duration-500 ease-studio hover:text-white"
            >
              Close
            </button>
          </div>
        </div>
        <h2
          id={titleId}
          className="mt-3 overflow-hidden font-display text-[clamp(1.75rem,2.4vw,2.5rem)] font-semibold uppercase leading-[1.05] tracking-[-0.04em] text-white"
        >
          <motion.span
            className="block"
            initial={{ y: reduce ? "0%" : "100%" }}
            animate={{ y: "0%" }}
            transition={reduce ? { duration: 0 } : { duration: 0.9, delay: 0.08, ease: EASE }}
          >
            {project.title}
          </motion.span>
        </h2>
        <p className="mt-2 font-mono text-[11px] uppercase tracking-[0.2em] text-white/60">
          {architecture}
        </p>
      </header>
      <div ref={wrapperRef} data-case-scroll className="min-h-0 overflow-hidden">
        <div ref={contentRef} className="px-6 pt-2 pb-6 sm:px-8">
          <div className="max-h-[240px] overflow-hidden rounded-[24px] border border-white/10 bg-[#030305] p-2">
            <div className="relative h-[200px] overflow-hidden rounded-[16px]">
              <ProjectPreview variant={project.variant} ignorePause />
            </div>
          </div>
          <div className="mt-4 max-w-3xl space-y-3">
            {notes.map((note) => (
              <p
                key={note}
                className="font-mono text-[16px] leading-[1.5] tracking-normal text-white/80 normal-case"
              >
                {note}
              </p>
            ))}
          </div>
        </div>
      </div>
    </>
  )
}
