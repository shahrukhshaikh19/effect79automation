import { motion, useReducedMotion, useSpring } from "framer-motion"
import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from "react"
import { EASE } from "../ease"

const LINKS = [
  { label: "Work", href: "#work" },
  { label: "Lab", href: "#lab" },
  { label: "Shaders", href: "#shaders" },
  { label: "Studio", href: "#studio" },
] as const

type LinkLabel = (typeof LINKS)[number]["label"]

const SPRING = { stiffness: 320, damping: 28, mass: 0.4 }

function useMagneticShift(enabled: boolean) {
  const x = useSpring(0, SPRING)
  const y = useSpring(0, SPRING)

  const onPointerMove = (event: ReactPointerEvent<HTMLElement>) => {
    if (!enabled) return
    const rect = event.currentTarget.getBoundingClientRect()
    const dx = event.clientX - (rect.left + rect.width / 2)
    const dy = event.clientY - (rect.top + rect.height / 2)
    x.set(Math.max(-6, Math.min(6, dx * 0.22)))
    y.set(Math.max(-4, Math.min(4, dy * 0.3)))
  }

  const onPointerLeave = () => {
    x.set(0)
    y.set(0)
  }

  return { x, y, onPointerMove, onPointerLeave }
}

function StatusDot() {
  const reduce = useReducedMotion()

  return (
    <span className="relative grid h-2 w-2 shrink-0 place-items-center" aria-hidden>
      {reduce ? null : (
        <motion.span
          className="absolute inset-0 rounded-full bg-[#9EE6C3]/45"
          initial={{ scale: 1, opacity: 0.55 }}
          animate={{ scale: 2.15, opacity: 0 }}
          transition={{ duration: 2.2, repeat: Infinity, ease: EASE }}
        />
      )}
      <span className="h-1.5 w-1.5 rounded-full bg-[#9EE6C3]" />
    </span>
  )
}

const BAR_REST = [0.42, 0.78, 0.55, 1]

function SoundBars({ on }: { on: boolean }) {
  const reduce = useReducedMotion()

  return (
    <span className="flex h-3 items-end gap-[3px]" aria-hidden>
      {BAR_REST.map((level, bar) => (
        <motion.span
          key={bar}
          className="w-[2px] origin-bottom bg-current"
          style={{ height: 12 }}
          animate={{
            scaleY: on
              ? reduce
                ? level
                : [level * 0.4, level, level * 0.62, level]
              : level * 0.7,
          }}
          transition={
            on && !reduce
              ? { duration: 1.05, repeat: Infinity, delay: bar * 0.09, ease: EASE }
              : { duration: 0.45, ease: EASE }
          }
        />
      ))}
    </span>
  )
}

function NavLink({
  label,
  href,
  selected,
  current,
  onSelect,
  onHover,
  onHoverEnd,
}: {
  label: string
  href: string
  selected: boolean
  current: boolean
  onSelect: () => void
  onHover: () => void
  onHoverEnd: () => void
}) {
  const reduce = useReducedMotion()
  const { x, y, onPointerMove, onPointerLeave } = useMagneticShift(!reduce)

  return (
    <a
      href={href}
      aria-current={current ? "true" : undefined}
      className={`relative inline-flex items-center rounded-full px-0.5 py-1 font-mono text-[10px] uppercase tracking-normal transition-colors duration-500 ease-studio focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-white/40 min-[360px]:px-1 min-[360px]:tracking-[0.04em] sm:px-3 sm:text-[11px] sm:tracking-[0.2em] ${
        current || selected ? "text-white" : "text-white/60 hover:text-white"
      }`}
      onClick={(event) => {
        event.preventDefault()
        onSelect()
      }}
      onPointerEnter={onHover}
      onPointerMove={onPointerMove}
      onPointerLeave={() => {
        onPointerLeave()
        onHoverEnd()
      }}
      onFocus={onHover}
      onBlur={onHoverEnd}
    >
      {selected ? (
        <motion.span
          layoutId="studio-nav-pill"
          className="absolute inset-0 z-0 rounded-full bg-white/[0.08] shadow-[inset_0_1px_0_0_rgba(255,255,255,0.28)]"
          transition={
            reduce
              ? { layout: { duration: 0 } }
              : { layout: { type: "tween", duration: 0.6, ease: EASE } }
          }
        />
      ) : null}
      <motion.span className="relative z-10 block" style={{ x, y }}>
        {label}
      </motion.span>
    </a>
  )
}

export function StudioNav() {
  const dockRef = useRef<HTMLElement>(null)
  const reduce = useReducedMotion()
  const [active, setActive] = useState<LinkLabel>("Work")
  const [hovered, setHovered] = useState<LinkLabel | null>(null)
  const [soundOn, setSoundOn] = useState(false)
  const indicator = hovered ?? active
  const contact = useMagneticShift(!reduce)

  useEffect(() => {
    const el = dockRef.current
    if (!el) return

    let frame = 0
    let nextX = 50
    let nextY = 0

    const paint = () => {
      frame = 0
      el.style.setProperty("--x", `${nextX}%`)
      el.style.setProperty("--y", `${nextY}%`)
    }

    const queue = () => {
      if (frame) return
      frame = window.requestAnimationFrame(paint)
    }

    const onPointerMove = (event: PointerEvent) => {
      const rect = el.getBoundingClientRect()
      if (rect.width === 0 || rect.height === 0) return
      nextX = ((event.clientX - rect.left) / rect.width) * 100
      nextY = ((event.clientY - rect.top) / rect.height) * 100
      queue()
    }

    const onPointerLeave = () => {
      nextX = 50
      nextY = 0
      queue()
    }

    el.addEventListener("pointermove", onPointerMove)
    el.addEventListener("pointerleave", onPointerLeave)

    return () => {
      window.cancelAnimationFrame(frame)
      el.removeEventListener("pointermove", onPointerMove)
      el.removeEventListener("pointerleave", onPointerLeave)
    }
  }, [])

  return (
    <header
      ref={dockRef}
      className="studio-dock fixed top-6 inset-x-0 z-50 mx-auto flex w-fit max-w-[calc(100%-0.75rem)] items-center gap-0.5 overflow-x-auto rounded-full border border-white/[0.12] bg-white/[0.04] px-2 py-2.5 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.35)] backdrop-blur-md backdrop-saturate-150 transform-gpu min-[360px]:max-w-[calc(100%-1rem)] min-[360px]:gap-1 min-[360px]:px-2.5 sm:max-w-[calc(100%-1.5rem)] sm:gap-5 sm:px-6"
    >
      <div className="flex shrink-0 items-center gap-2">
        <span className="font-display text-[11px] font-semibold uppercase tracking-[0.08em] text-white min-[360px]:tracking-[0.12em] sm:text-[12px] sm:tracking-[0.18em]">
          Vitre
        </span>
        <span className="flex items-center gap-2">
          <StatusDot />
          <span className="hidden font-mono text-[11px] uppercase tracking-[0.2em] text-white/55 lg:inline">
            Available for Q4
          </span>
        </span>
      </div>

      <span className="hidden h-3 w-px shrink-0 bg-white/15 sm:block" aria-hidden />

      <nav aria-label="Studio" className="flex shrink-0 items-center">
        {LINKS.map((link) => (
          <NavLink
            key={link.label}
            label={link.label}
            href={link.href}
            selected={indicator === link.label}
            current={active === link.label}
            onSelect={() => setActive(link.label)}
            onHover={() => setHovered(link.label)}
            onHoverEnd={() =>
              setHovered((current) => (current === link.label ? null : current))
            }
          />
        ))}
      </nav>

      <span className="hidden h-3 w-px shrink-0 bg-white/15 sm:block" aria-hidden />

      <div className="flex shrink-0 items-center gap-1 sm:gap-2">
        <motion.button
          type="button"
          aria-pressed={soundOn}
          aria-label="Sound"
          onClick={() => setSoundOn((value) => !value)}
          whileTap={reduce ? undefined : { scale: 0.94 }}
          transition={{ duration: 0.4, ease: EASE }}
          className="grid h-6 w-6 shrink-0 place-items-center rounded-full text-white/75 transition-colors duration-500 ease-studio hover:text-white focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-white/40 min-[360px]:h-7 min-[360px]:w-7 sm:h-8 sm:w-8"
        >
          <SoundBars on={soundOn} />
        </motion.button>
        <button
          type="button"
          className="rounded-full px-0.5 py-1 font-mono text-[10px] uppercase tracking-normal text-white/75 transition-colors duration-500 ease-studio hover:text-white focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-white/40 min-[360px]:px-1 min-[360px]:tracking-[0.04em] sm:px-2.5 sm:text-[11px] sm:tracking-[0.2em]"
          onPointerMove={contact.onPointerMove}
          onPointerLeave={contact.onPointerLeave}
        >
          <motion.span className="block" style={{ x: contact.x, y: contact.y }}>
            Contact
          </motion.span>
        </button>
      </div>
    </header>
  )
}
