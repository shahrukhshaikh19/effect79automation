import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { useEffect, useMemo, useRef, useState } from "react"
import * as THREE from "three"
import { isStagePaused, subscribeStagePaused } from "../stagePause"

const vertexShader = /* glsl */ `
  void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

const fragmentShader = /* glsl */ `
  uniform float uTime;
  uniform float uVariant;
  uniform vec2 uResolution;

  void main() {
    vec2 uv = gl_FragCoord.xy / uResolution.xy;
    float aspect = uResolution.x / max(uResolution.y, 1.0);
    vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
    float t = uTime * 0.22;
    float v = uVariant;
    float field = 0.0;

    if (v < 0.5) {
      float wave = sin(p.x * 2.2 + t) * 0.12;
      field = exp(-pow((p.y - wave) * 3.1, 2.0));
      field += exp(-pow((p.y + 0.26) * 11.0, 2.0)) * 0.4;
    } else if (v < 1.5) {
      float radius = length(p);
      field = pow(0.5 + 0.5 * sin(radius * 16.0 - t * 1.6), 10.0);
    } else if (v < 2.5) {
      field = pow(0.5 + 0.5 * sin(p.x * 9.0 + sin(p.y * 2.2 + t) * 1.5), 7.0);
      field *= smoothstep(0.95, 0.15, abs(p.y));
    } else if (v < 3.5) {
      float diagonal = p.x * 0.72 + p.y;
      field = exp(-pow(fract(diagonal * 2.2 - t * 0.06) - 0.5, 2.0) * 32.0);
    } else if (v < 4.5) {
      vec2 grid = abs(fract(p * vec2(4.2, 5.4) + vec2(t * 0.04, 0.0)) - 0.5);
      field = smoothstep(0.045, 0.0, min(grid.x, grid.y));
    } else {
      float arc = abs(length(p - vec2(-0.15, 0.08)) - 0.42);
      field = exp(-arc * arc * 220.0);
      field += exp(-pow((p.y + 0.22) * 5.5, 2.0)) * 0.4;
    }

    vec3 obsidian = vec3(0.0118, 0.0118, 0.0196);
    vec3 ice = vec3(0.74, 0.84, 0.96);
    vec3 color = obsidian + ice * field * 0.5;
    float grain = fract(sin(dot(gl_FragCoord.xy, vec2(127.1, 311.7))) * 43758.5453);
    color += (grain - 0.5) * 0.014;
    float vignette = smoothstep(1.15, 0.22, length(p));
    color *= mix(0.5, 1.0, vignette);
    gl_FragColor = vec4(color, 1.0);
  }
`

function PreviewField({
  variant,
  running,
}: {
  variant: number
  running: { current: boolean }
}) {
  const materialRef = useRef<THREE.ShaderMaterial>(null)
  const width = useThree((state) => state.viewport.width)
  const height = useThree((state) => state.viewport.height)
  const uniforms = useMemo(
    () => ({
      uTime: { value: variant * 1.7 },
      uVariant: { value: variant },
      uResolution: { value: new THREE.Vector2(1, 1) },
    }),
    [variant],
  )

  useFrame((state, delta) => {
    const material = materialRef.current
    if (!material || !running.current) return
    const pixelRatio = state.gl.getPixelRatio()
    material.uniforms.uResolution.value.set(
      state.size.width * pixelRatio,
      state.size.height * pixelRatio,
    )
    material.uniforms.uTime.value += delta
  })

  return (
    <mesh scale={[width, height, 1]} frustumCulled={false} raycast={() => null}>
      <planeGeometry args={[1, 1]} />
      <shaderMaterial
        ref={materialRef}
        uniforms={uniforms}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        depthTest={false}
        depthWrite={false}
        toneMapped={false}
      />
    </mesh>
  )
}

export function ProjectPreview({
  variant,
  ignorePause = false,
}: {
  variant: number
  ignorePause?: boolean
}) {
  const hostRef = useRef<HTMLDivElement>(null)
  const invalidateRef = useRef<() => void>(() => {})
  const running = useRef(false)
  const ignorePauseRef = useRef(ignorePause)
  const [mounted, setMounted] = useState(false)
  ignorePauseRef.current = ignorePause

  useEffect(() => {
    const host = hostRef.current
    if (!host) return

    const motion = window.matchMedia("(prefers-reduced-motion: reduce)")
    let frame = 0
    let alive = true

    const blocked = () => !ignorePauseRef.current && isStagePaused()

    const loop = () => {
      frame = 0
      if (!alive || !running.current || blocked()) return
      invalidateRef.current()
      if (!motion.matches) frame = window.requestAnimationFrame(loop)
    }

    const kick = () => {
      if (!frame) frame = window.requestAnimationFrame(loop)
    }

    const start = () => {
      running.current = true
      setMounted(true)
      if (!blocked()) kick()
    }

    const stop = () => {
      running.current = false
      if (frame) window.cancelAnimationFrame(frame)
      frame = 0
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) start()
        else stop()
      },
      { rootMargin: "30% 0px" },
    )
    observer.observe(host)

    const unsubscribe = subscribeStagePaused(() => {
      if (!running.current) return
      if (blocked()) {
        if (frame) window.cancelAnimationFrame(frame)
        frame = 0
        return
      }
      kick()
    })

    return () => {
      alive = false
      stop()
      observer.disconnect()
      unsubscribe()
    }
  }, [])

  return (
    <div ref={hostRef} className="absolute inset-0 bg-[#030305]" aria-hidden>
      {mounted ? (
        <Canvas
          className="block h-full w-full"
          dpr={[1, 1.2]}
          frameloop="demand"
          gl={{
            antialias: false,
            alpha: false,
            depth: false,
            stencil: false,
            powerPreference: "high-performance",
          }}
          camera={{ position: [0, 0, 1], fov: 40, near: 0.1, far: 10 }}
          onCreated={({ gl, invalidate }) => {
            gl.setClearColor("#030305", 1)
            gl.toneMapping = THREE.NoToneMapping
            invalidateRef.current = invalidate
            invalidate()
          }}
        >
          <PreviewField variant={variant} running={running} />
        </Canvas>
      ) : null}
    </div>
  )
}
