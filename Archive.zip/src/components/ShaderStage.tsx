import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { useEffect, useMemo, useRef } from "react"
import * as THREE from "three"
import { useStagePaused } from "../stagePause"

const vertexShader = /* glsl */ `
  void main() {
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`

const fragmentShader = /* glsl */ `
  uniform float uTime;
  uniform vec2 uMouse;
  uniform vec2 uResolution;

  void main() {
    vec2 uv = gl_FragCoord.xy / uResolution.xy;
    float aspect = uResolution.x / max(uResolution.y, 1.0);
    vec2 p = (uv - 0.5) * vec2(aspect, 1.0);
    vec2 m = (uMouse - 0.5) * vec2(aspect, 1.0);

    float t = uTime * 0.18;
    float wave = sin(p.x * 1.5 + t) * 0.1 + sin(p.x * 2.8 - t * 0.65) * 0.035;
    float band = exp(-pow((p.y - 0.16 - wave) * 2.8, 2.0));
    float ridge = exp(-pow((p.y + 0.34 - sin(p.x * 0.7 - t * 0.4) * 0.06) * 9.0, 2.0));

    vec2 q = p - m * 0.85;
    float lens = exp(-dot(q, q) * 2.6);
    float grain = fract(sin(dot(gl_FragCoord.xy, vec2(127.1, 311.7))) * 43758.5453);

    vec3 obsidian = vec3(0.0118, 0.0118, 0.0196);
    vec3 ice = vec3(0.74, 0.83, 0.96);

    vec3 color = obsidian;
    color += ice * band * 0.26;
    color += ice * ridge * 0.045;
    color += ice * lens * 0.18;
    color += (grain - 0.5) * 0.012;

    float vignette = smoothstep(1.2, 0.2, length(p));
    color *= mix(0.58, 1.0, vignette);

    gl_FragColor = vec4(color, 1.0);
  }
`

function LightField() {
  const materialRef = useRef<THREE.ShaderMaterial>(null)
  const reduced = useRef(false)
  const target = useRef(new THREE.Vector2(0.5, 0.5))
  const current = useRef(new THREE.Vector2(0.5, 0.5))
  const width = useThree((state) => state.viewport.width)
  const height = useThree((state) => state.viewport.height)

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0.5, 0.5) },
      uResolution: {
        value: new THREE.Vector2(window.innerWidth, window.innerHeight),
      },
    }),
    [],
  )

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)")
    const update = () => {
      reduced.current = media.matches
    }
    update()
    media.addEventListener("change", update)

    const onPointerMove = (event: PointerEvent) => {
      target.current.set(
        event.clientX / window.innerWidth,
        1 - event.clientY / window.innerHeight,
      )
    }
    window.addEventListener("pointermove", onPointerMove, { passive: true })

    return () => {
      media.removeEventListener("change", update)
      window.removeEventListener("pointermove", onPointerMove)
    }
  }, [])

  useFrame((state, delta) => {
    const material = materialRef.current
    if (!material) return

    const pixelRatio = state.gl.getPixelRatio()
    material.uniforms.uResolution.value.set(
      state.size.width * pixelRatio,
      state.size.height * pixelRatio,
    )
    current.current.lerp(target.current, 1 - Math.exp(-3.2 * delta))
    material.uniforms.uMouse.value.copy(current.current)
    if (!reduced.current) material.uniforms.uTime.value += delta
  })

  return (
    <mesh scale={[width, height, 1]} frustumCulled={false}>
      <planeGeometry args={[1, 1]} />
      <shaderMaterial
        ref={materialRef}
        uniforms={uniforms}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        depthTest={false}
        depthWrite={false}
        toneMapped={false}
      />
    </mesh>
  )
}

export function ShaderStage() {
  const paused = useStagePaused()

  return (
    <div className="pointer-events-none absolute inset-0 bg-[#030305]" aria-hidden>
      <Canvas
        className="block h-full w-full"
        dpr={[1, 1.5]}
        frameloop={paused ? "never" : "always"}
        gl={{
          antialias: false,
          alpha: false,
          depth: false,
          stencil: false,
          powerPreference: "high-performance",
        }}
        camera={{ position: [0, 0, 1], fov: 40, near: 0.1, far: 10 }}
        onCreated={({ gl }) => {
          gl.setClearColor("#030305", 1)
          gl.toneMapping = THREE.NoToneMapping
        }}
      >
        <LightField />
      </Canvas>
    </div>
  )
}
